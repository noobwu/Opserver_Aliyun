Configuration files go here!

Example files are provided, these are close to the Stack Overflow production configs and serve as a reference.
All JSON config files (not just the examples) support comments for easy editing, testing, etc. 